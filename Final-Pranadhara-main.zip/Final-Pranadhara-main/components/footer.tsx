export function Footer() {
  return (
    <footer className="border-t border-border bg-muted/50">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center text-sm text-muted-foreground">
          <p className="font-medium text-foreground">
            <a
              href="https://vitsitdepartment.vercel.app/clubs"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:underline hover:text-primary transition-colors"
            >
              Made By NextGen - Department Software Development Cell (NG-DSDC) - Dept. Of IT
            </a>
          </p>
        </div>
      </div>
    </footer>
  )
}
