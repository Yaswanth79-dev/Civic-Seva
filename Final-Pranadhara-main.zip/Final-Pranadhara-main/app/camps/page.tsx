"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Calendar, MapPin, Clock, Search, ArrowRight } from "lucide-react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { fetchGoogleSheetData, parseCampsData, formatGoogleDriveUrl } from "@/lib/google-sheets"
import type { Camp } from "@/lib/types"

export default function CampsPage() {
    const [camps, setCamps] = useState<Camp[]>([])
    const [loading, setLoading] = useState(true)
    const [selectedCamp, setSelectedCamp] = useState<Camp | null>(null)

    useEffect(() => {
        async function loadCamps() {
            const apiKey = process.env.NEXT_PUBLIC_GOOGLE_SHEETS_API_KEY
            const spreadsheetId = process.env.NEXT_PUBLIC_CAMPS_SPREADSHEET_ID

            if (!apiKey || !spreadsheetId) {
                console.error("Google Sheets configuration is missing.")
                setLoading(false)
                return
            }

            try {
                console.log("Fetching camps data from Google Sheets...")
                const data = await fetchGoogleSheetData({
                    apiKey,
                    spreadsheetId,
                    range: "Sheet1!A:Z",
                })

                const parsedCamps = parseCampsData(data)
                console.log("Parsed camps:", parsedCamps)
                setCamps(parsedCamps)
            } catch (error) {
                console.error("Error loading camps:", error)
            } finally {
                setLoading(false)
            }
        }

        loadCamps()
    }, [])

    return (
        <div className="flex min-h-screen flex-col">
            <Navbar />
            <main className="flex-1">
                <section className="py-12 md:py-20 bg-muted/50">
                    <div className="container mx-auto px-4">
                        <div className="text-center mb-12">
                            <Calendar className="h-12 w-12 text-primary mx-auto mb-4" />
                            <h1 className="text-2xl md:text-4xl font-sans font-extrabold mb-4 max-w-4xl mx-auto leading-tight text-foreground tracking-tight">
                                "Blood cannot be manufactured — it can only be donated."
                            </h1>
                        </div>

                        {loading ? (
                            <div className="text-center py-12">
                                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
                                <p className="mt-4 text-muted-foreground">Loading upcoming camps...</p>
                            </div>
                        ) : camps.length > 0 ? (
                            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                                {camps.map((camp, index) => (
                                    <Card
                                        key={camp.id}
                                        className="group overflow-hidden border-none bg-background/50 backdrop-blur-sm shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 animate-in fade-in slide-in-from-bottom-4"
                                        style={{ animationDelay: `${index * 100}ms` }}
                                    >
                                        <div
                                            className="aspect-[16/10] relative overflow-hidden cursor-pointer"
                                            onClick={() => setSelectedCamp(camp)}
                                        >
                                            <Image
                                                src={camp.imageUrl || "/placeholder-camp.svg"}
                                                alt={camp.name}
                                                fill
                                                className="object-cover transition-all duration-700 group-hover:scale-110 group-hover:rotate-1"
                                                unoptimized
                                                referrerPolicy="no-referrer"
                                                onError={(e) => {
                                                    e.currentTarget.src = "/placeholder-camp.svg"
                                                }}
                                            />
                                            {/* Media Overlay */}
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-60 group-hover:opacity-100 transition-opacity duration-500" />

                                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-y-4 group-hover:translate-y-0">
                                                <div className="bg-white/20 backdrop-blur-xl border border-white/30 px-6 py-3 rounded-full flex items-center gap-2 text-white font-bold shadow-2xl">
                                                    <Search className="h-4 w-4" />
                                                    View Gallery
                                                </div>
                                            </div>

                                            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-white drop-shadow-lg">
                                                <div className="flex items-center gap-2 text-xs font-semibold bg-primary/90 px-2 py-1 rounded-md backdrop-blur-sm">
                                                    <Calendar className="h-3 w-3" />
                                                    {camp.date}
                                                </div>
                                                <div className="bg-black/40 backdrop-blur-md px-2 py-1 rounded-md text-xs border border-white/10 uppercase tracking-widest font-bold">
                                                    {camp.district || "Event"}
                                                </div>
                                            </div>
                                        </div>

                                        <CardContent className="p-6 relative">
                                            <div className="mb-4">
                                                <h3 className="text-xl font-bold mb-2 line-clamp-1 group-hover:text-primary transition-colors duration-300">
                                                    {camp.name}
                                                </h3>
                                                <p className="flex items-center text-sm text-muted-foreground">
                                                    <MapPin className="mr-1.5 h-3.5 w-3.5 text-primary" />
                                                    {camp.location}
                                                </p>
                                            </div>

                                            <p className="text-sm text-muted-foreground mb-6 line-clamp-2 leading-relaxed italic">
                                                "{camp.description || "Every donation is a step towards saving a life. Join us in this noble cause."}"
                                            </p>

                                            <div className="flex items-center justify-between pt-4 border-t border-border/50">
                                                <div className="flex flex-col">
                                                    <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Organizer</span>
                                                    <span className="text-sm font-semibold">{camp.organizer}</span>
                                                </div>
                                                <Button
                                                    variant="ghost"
                                                    size="sm"
                                                    className="rounded-full hover:bg-primary hover:text-white group/btn"
                                                    onClick={() => setSelectedCamp(camp)}
                                                >
                                                    Details
                                                    <ArrowRight className="ml-1 h-3 w-3 group-hover/btn:translate-x-1 transition-transform" />
                                                </Button>
                                            </div>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        ) : (
                            <div className="text-center py-12 bg-background rounded-lg border shadow-sm">
                                <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                                <h3 className="text-lg font-medium mb-2">No Upcoming Camps</h3>
                                <p className="text-muted-foreground">No upcoming camps at the moment. Check back soon!</p>
                            </div>
                        )}
                    </div>
                </section>
            </main>
            <Footer />

            <Dialog open={!!selectedCamp} onOpenChange={(open: boolean) => !open && setSelectedCamp(null)}>
                <DialogContent className="max-w-4xl max-h-[95vh] overflow-y-auto p-0 gap-0 border-none bg-background/80 backdrop-blur-xl">
                    {selectedCamp && (
                        <div className="relative">
                            {/* Hero Image Section */}
                            <div className="aspect-video relative w-full overflow-hidden">
                                <Image
                                    src={selectedCamp.imageUrl || "/placeholder-camp.svg"}
                                    alt={selectedCamp.name}
                                    fill
                                    className="object-cover"
                                    unoptimized
                                    referrerPolicy="no-referrer"
                                />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                                <div className="absolute bottom-0 left-0 p-8 w-full">
                                    <div className="flex flex-col gap-2">
                                        <div className="flex items-center gap-2">
                                            <span className="px-3 py-1 bg-primary text-primary-foreground text-xs font-bold rounded-full uppercase tracking-wider">
                                                {selectedCamp.status || "Completed"}
                                            </span>
                                            <DialogDescription asChild>
                                                <span className="text-white/80 text-sm flex items-center gap-1">
                                                    <Calendar className="h-3.5 w-3.5" />
                                                    {selectedCamp.date}
                                                </span>
                                            </DialogDescription>
                                        </div>
                                        <DialogTitle className="text-3xl md:text-4xl font-bold text-white tracking-tight">
                                            {selectedCamp.name}
                                        </DialogTitle>
                                        <p className="text-white/90 flex items-center gap-2">
                                            <MapPin className="h-4 w-4 text-primary" />
                                            {selectedCamp.location}{selectedCamp.district ? `, ${selectedCamp.district}` : ""}
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div className="p-8 space-y-8">
                                {/* Stats / Info Bar */}
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 rounded-2xl bg-muted/50 border border-border">
                                    <div className="text-center">
                                        <p className="text-xs text-muted-foreground uppercase font-semibold">Organized By</p>
                                        <p className="font-bold truncate">{selectedCamp.organizer}</p>
                                    </div>
                                    <div className="text-center border-l">
                                        <p className="text-xs text-muted-foreground uppercase font-semibold">Time</p>
                                        <p className="font-bold">{selectedCamp.time || "Full Day"}</p>
                                    </div>
                                    <div className="text-center border-l hidden md:block">
                                        <p className="text-xs text-muted-foreground uppercase font-semibold">Contact</p>
                                        <p className="font-bold">{selectedCamp.contact || "N/A"}</p>
                                    </div>
                                    <div className="text-center border-l hidden md:block">
                                        <p className="text-xs text-muted-foreground uppercase font-semibold">Impact</p>
                                        <p className="font-bold">Life Saving</p>
                                    </div>
                                </div>

                                {/* Description */}
                                <div className="prose dark:prose-invert max-w-none">
                                    <h3 className="text-xl font-bold mb-3 flex items-center gap-2">
                                        <div className="w-1 h-6 bg-primary rounded-full" />
                                        About the Event
                                    </h3>
                                    <p className="text-muted-foreground leading-relaxed text-lg">
                                        {selectedCamp.description || "Join us in our mission to save lives. Every drop counts. This blood donation camp is organized to support local blood banks and ensure that patients in need have access to safe blood."}
                                    </p>
                                </div>

                                {/* Media Gallery Section */}
                                <div>
                                    <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                                        <div className="w-1 h-6 bg-primary rounded-full" />
                                        Event Gallery
                                    </h3>
                                    {selectedCamp.gallery && selectedCamp.gallery.length > 0 ? (
                                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                            {selectedCamp.gallery.map((img, index) => (
                                                <div
                                                    key={index}
                                                    className="aspect-[4/5] relative rounded-2xl overflow-hidden bg-muted group cursor-zoom-in"
                                                >
                                                    <Image
                                                        src={img}
                                                        alt={`Camp Gallery ${index + 1}`}
                                                        fill
                                                        className="object-cover transition-all duration-500 group-hover:scale-110 group-hover:rotate-1"
                                                        unoptimized
                                                        referrerPolicy="no-referrer"
                                                    />
                                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                                                        <span className="text-white text-xs font-bold uppercase tracking-widest bg-white/20 backdrop-blur-md px-4 py-2 rounded-full border border-white/30">
                                                            Enlarge
                                                        </span>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    ) : (
                                        <div className="text-center py-12 bg-muted/30 rounded-2xl border border-dashed border-border/50">
                                            <p className="text-muted-foreground italic font-medium">
                                                More memories coming soon! Stay tuned.
                                            </p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                </DialogContent>
            </Dialog>
        </div>
    )
}
