import { auth, db } from "./firebase"
import { collection, query, where, getDocs, addDoc, updateDoc, doc, Timestamp, setDoc, getDoc } from "firebase/firestore"
import type { Donor, EmergencyRequest } from "./types"

// Donor operations
export async function addDonor(donorData: Omit<Donor, "id" | "createdAt" | "updatedAt">) {
  try {
    if (!db) {
      throw new Error("Firebase not initialized")
    }
    const currentUser = auth?.currentUser

    // If the user is authenticated, store the donor doc using their UID as the document ID
    if (currentUser?.uid) {
      const donorRef = doc(db, "donors", currentUser.uid)
      await setDoc(
        donorRef,
        {
          ...donorData,
          createdAt: Timestamp.now(),
          updatedAt: Timestamp.now(),
        },
        { merge: true },
      )
      // Update the public stats counter
      try {
        const { doc, setDoc, increment } = await import("firebase/firestore");
        const statsRef = doc(db, "stats", "general");
        await setDoc(statsRef, {
          activeDonors: increment(1),
          lastUpdated: Timestamp.now()
        }, { merge: true });
      } catch (statsError) {
        console.error("Failed to update public stats counter:", statsError);
      }

      return donorRef.id
    }

    // Fallback: create a random-id document if auth user is not available (should be rare)
    const randomRef = await addDoc(collection(db, "donors"), {
      ...donorData,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now(),
    })
    // Update the public stats counter
    try {
      const { doc, setDoc, increment } = await import("firebase/firestore");
      const statsRef = doc(db, "stats", "general");
      await setDoc(statsRef, {
        activeDonors: increment(1),
        lastUpdated: Timestamp.now()
      }, { merge: true });
    } catch (statsError) {
      console.error("Failed to update public stats counter:", statsError);
    }

    return randomRef.id
  } catch (error) {
    console.error("Error adding donor:", error)
    if (error instanceof Error && error.message.includes("permissions")) {
      throw new Error("Firebase permissions error. Please check Firestore security rules.")
    }
    throw error
  }
}

export async function getDonorsByBloodGroup(bloodGroup: string) {
  try {
    const q = query(collection(db, "donors"), where("bloodGroup", "==", bloodGroup), where("isAvailable", "==", true))
    const querySnapshot = await getDocs(q)
    return querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }) as Donor)
  } catch (error) {
    console.error("Error fetching donors:", error)
    throw error
  }
}

export async function getDonorsByDistrict(district: string) {
  try {
    const q = query(collection(db, "donors"), where("district", "==", district), where("isAvailable", "==", true))
    const querySnapshot = await getDocs(q)
    return querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }) as Donor)
  } catch (error) {
    console.error("Error fetching donors by district:", error)
    throw error
  }
}

export async function updateDonorAvailability(donorId: string, isAvailable: boolean) {
  try {
    const donorRef = doc(db, "donors", donorId)
    await updateDoc(donorRef, {
      isAvailable,
      updatedAt: Timestamp.now(),
    })
  } catch (error) {
    console.error("Error updating donor availability:", error)
    throw error
  }
}

export async function searchDonors(bloodGroup?: string, district?: string) {
  try {
    let q = query(collection(db, "donors"), where("isAvailable", "==", true))

    if (bloodGroup && district) {
      q = query(
        collection(db, "donors"),
        where("isAvailable", "==", true),
        where("bloodGroup", "==", bloodGroup),
        where("district", "==", district),
      )
    } else if (bloodGroup) {
      q = query(collection(db, "donors"), where("isAvailable", "==", true), where("bloodGroup", "==", bloodGroup))
    } else if (district) {
      q = query(collection(db, "donors"), where("isAvailable", "==", true), where("district", "==", district))
    }

    const querySnapshot = await getDocs(q)
    return querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }) as Donor)
  } catch (error) {
    console.error("Error searching donors:", error)
    throw error
  }
}

// Emergency request operations
export async function createEmergencyRequest(requestData: Omit<EmergencyRequest, "id" | "createdAt">) {
  try {
    const docRef = await addDoc(collection(db, "emergencyRequests"), {
      ...requestData,
      createdAt: Timestamp.now(),
    })
    return docRef.id
  } catch (error) {
    console.error("Error creating emergency request:", error)
    throw error
  }
}

export async function getEmergencyRequests(status = "open") {
  try {
    const q = query(collection(db, "emergencyRequests"), where("status", "==", status))
    const querySnapshot = await getDocs(q)
    return querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }) as EmergencyRequest)
  } catch (error) {
    console.error("Error fetching emergency requests:", error)
    throw error
  }
}

export async function getHomeStats() {
  const { getCountFromServer, doc, getDoc, setDoc, collection, query, where, Timestamp } = await import("firebase/firestore")

  let activeDonors = 0
  let livesSaved = 0

  try {
    // 1. Try to read from public stats cache
    try {
      const statsRef = doc(db, "stats", "general")
      const statsSnap = await getDoc(statsRef)
      if (statsSnap.exists()) {
        activeDonors = statsSnap.data().activeDonors || 0
      }
    } catch (e) {
      console.warn("Stats cache read failed", e)
    }

    // 2. If we are logged in, we can try to fetch real data and update cache
    try {
      // This will throw if not logged in due to rules
      const donorsColl = collection(db, "donors")
      const donorsSnap = await getCountFromServer(donorsColl)
      const realCount = donorsSnap.data().count

      // Update our local variable
      activeDonors = realCount

      // And heal the cache
      const statsRef = doc(db, "stats", "general")
      setDoc(statsRef, {
        activeDonors: realCount,
        lastUpdated: Timestamp.now()
      }, { merge: true }).catch(err => console.error("Cache update failed", err))

    } catch (e: any) {
      // Ignore permission errors; keep the cached value or 0
    }

    // 3. Lives Saved is public
    try {
      const requestsColl = collection(db, "emergencyRequests")
      const requestsSnap = await getCountFromServer(query(requestsColl, where("status", "in", ["fulfilled", "closed"])))
      livesSaved = requestsSnap.data().count
    } catch (e) {
      console.error("Lives saved fetch failed", e)
    }

    return {
      activeDonors,
      livesSaved,
    }

  } catch (error) {
    console.error("Unexpected error in getHomeStats:", error)
    return {
      activeDonors: 0,
      livesSaved: 0
    }
  }
}


export async function getBloodGroupStats() {
  try {
    const donorsSnapshot = await getDocs(collection(db, "donors"))
    const stats: Record<string, number> = {
      "O+": 0, "O-": 0, "A+": 0, "A-": 0, "B+": 0, "B-": 0, "AB+": 0, "AB-": 0
    }

    let total = 0
    donorsSnapshot.forEach((doc) => {
      const data = doc.data()
      if (data.bloodGroup && stats[data.bloodGroup] !== undefined) {
        stats[data.bloodGroup]++
        total++
      }
    })

    return { stats, total }
  } catch (error) {
    console.error("Error fetching blood group stats:", error)
    return { stats: {}, total: 0 }
  }
}
